
document.querySelector('.register').addEventListener('click', function()
{
    document.querySelector('.cont').classList.toggle('s-signup')
}
);


document.querySelector('.login').addEventListener('click', function()
{
    document.querySelector('.cont').classList.toggle('s-signup')
}
);